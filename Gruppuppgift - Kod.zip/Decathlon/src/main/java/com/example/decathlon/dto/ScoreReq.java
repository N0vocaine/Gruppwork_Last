package com.example.decathlon.dto;

public record ScoreReq(String name, String event, double raw) {}
